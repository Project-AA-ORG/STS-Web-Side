<!--

namespace App\Http\Controllers;

use App\Models\Event;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
class FileController extends Controller
{
    public function getEventImage($filename)
    {
        $filePath = 'path/to/storage/' . $filename; // Update this path according to your file structure
        
        // Check if the file exists in the storage directory
        if (Storage::exists($filePath)) {
            $file = Storage::get($filePath);
            $mimeType = Storage::mimeType($filePath);

            // Return the file as a response
            return response($file)->header('Content-Type', $mimeType);
        }

        // Handle if the file does not exist
        abort(404, 'File not found');
    }
}

 -->
